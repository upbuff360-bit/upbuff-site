import { getPermalink, getBlogPermalink, getAsset } from './utils/permalinks';

// export const headerData = {
//   links: [
//     {
//       text: 'Homes',
//       links: [
//         {
//           text: 'SaaS',
//           href: getPermalink('/homes/saas'),
//         },
//         {
//           text: 'Startup',
//           href: getPermalink('/homes/startup'),
//         },
//         {
//           text: 'Mobile App',
//           href: getPermalink('/homes/mobile-app'),
//         },
//         {
//           text: 'Personal',
//           href: getPermalink('/homes/personal'),
//         },
//       ],
//     },
//     {
//       text: 'Pages',
//       links: [
//         {
//           text: 'Features (Anchor Link)',
//           href: getPermalink('/#features'),
//         },
//         {
//           text: 'Services',
//           href: getPermalink('/services'),
//         },
//         {
//           text: 'Pricing',
//           href: getPermalink('/pricing'),
//         },
//         {
//           text: 'About us',
//           href: getPermalink('/about'),
//         },
//         {
//           text: 'Contact',
//           href: getPermalink('/contact'),
//         },
//         {
//           text: 'Terms',
//           href: getPermalink('/terms'),
//         },
//         {
//           text: 'Privacy policy',
//           href: getPermalink('/privacy'),
//         },
//       ],
//     },
//     {
//       text: 'Landing',
//       links: [
//         {
//           text: 'Lead Generation',
//           href: getPermalink('/landing/lead-generation'),
//         },
//         {
//           text: 'Long-form Sales',
//           href: getPermalink('/landing/sales'),
//         },
//         {
//           text: 'Click-Through',
//           href: getPermalink('/landing/click-through'),
//         },
//         {
//           text: 'Product Details (or Services)',
//           href: getPermalink('/landing/product'),
//         },
//         {
//           text: 'Coming Soon or Pre-Launch',
//           href: getPermalink('/landing/pre-launch'),
//         },
//         {
//           text: 'Subscription',
//           href: getPermalink('/landing/subscription'),
//         },
//       ],
//     },
//     {
//       text: 'Blog',
//       links: [
//         {
//           text: 'Blog List',
//           href: getBlogPermalink(),
//         },
//         {
//           text: 'Article',
//           href: getPermalink('get-started-website-with-astro-tailwind-css', 'post'),
//         },
//         {
//           text: 'Article (with MDX)',
//           href: getPermalink('markdown-elements-demo-post', 'post'),
//         },
//         {
//           text: 'Category Page',
//           href: getPermalink('tutorials', 'category'),
//         },
//         {
//           text: 'Tag Page',
//           href: getPermalink('astro', 'tag'),
//         },
//       ],
//     },
//     {
//       text: 'Widgets',
//       href: '#',
//     },
//   ],
//   actions: [{ text: 'Download', href: 'https://github.com/arthelokyo/astrowind', target: '_blank' }],
// };

export const headerData = {
  links: [
     {
      text: 'Home',
      href: getPermalink('/'),
    }
    ,
    
    {
      text: 'Platform',
      links: [
        {
          text: 'Overview',
          href: getPermalink('/homes/overview'),
        },
        {
          text: 'Why UpBuff',
          href: getPermalink('/homes/why-upbuff'),
        },
        {
          text: 'Security & Compliance',
          href: getPermalink('/homes/security-compliance'),
        },
      ],
    },
    
     {
       text: 'Solutions',
       links: [
        {
          text: 'By Industry',
           href: getPermalink('/homes/solutions'),
        },
      ],
         
    },
    {
      text: 'Products',
      links: [
        {
          text: 'ERP-Integrated CRM',
          href: getPermalink('/homes/erp-integrated-crm'),
        },
        {
          text: 'ERP-Integrated FSM',
          href: getPermalink('/homes/erp-integrated-fsm'),
        },
        {
          text: 'ERP-Integrated Warehouse',
          href: getPermalink('/homes/erp-integrated-warehouse-inventory'),
        },
        {
          text: 'Sales & Distribution Execution',
          href: getPermalink('/homes/erp-integrated-sales-distribution'),
        },
        {
          text: 'Manufacturing & Shopfloor',
          href: getPermalink('/homes/erp-integrated-manufacturing-shopfloor'),
        },
        {
          text: 'Enterprise & Partner Portals',
          href: getPermalink('/homes/enterprise-partner-portals'),
        },
        // {
        //   text: 'ERP Execution Platform',
        //   href: getPermalink('/homes/erp-execution-platform'),
        // },
        {
          text: 'ERP Integrated Product Configurator',
          href: getPermalink('/homes/erp-integrated-product-configurator'),
        }
      ],
    },
     {
       text: 'Integrations',
        links: [
        {
          text: 'Overview',
          href: getPermalink('/homes/integrations'),
        },
        {
          text: 'SAP Business One',
          href: getPermalink('/homes/sap-business-one'),
        }
      ],
    },
    // {
    //   text: 'Platform',
      // links: [
      //   {
      //     text: 'UpBuff Values',
      //     href: getPermalink('/#features'),
      //   },
      //   {
      //     text: 'About UpBuff',
      //     href: getPermalink('/about'),
      //   },
      //   {
      //     text: 'The Impact',
      //     href: getPermalink('/pricing'),
      //   },
      // ],
    // },
    
    // {
    //   text: 'Resourse',
    //   links: [
    //     {
    //       text: 'Lead Generation',
    //       href: getPermalink('/landing/lead-generation'),
    //     },
    //     {
    //       text: 'Long-form Sales',
    //       href: getPermalink('/landing/sales'),
    //     },
    //     {
    //       text: 'Click-Through',
    //       href: getPermalink('/landing/click-through'),
    //     },
    //     {
    //       text: 'Product Details (or Services)',
    //       href: getPermalink('/landing/product'),
    //     },
    //     {
    //       text: 'Coming Soon or Pre-Launch',
    //       href: getPermalink('/landing/pre-launch'),
    //     },
    //     {
    //       text: 'Subscription',
    //       href: getPermalink('/landing/subscription'),
    //     },
    //   ],
    // },
    {
      text: 'Blog',
      links: [
        {
          text: 'Blog List',
          href: getBlogPermalink(),
        },
        {
          text: 'Article',
          href: getPermalink('get-started-website-with-astro-tailwind-css', 'post'),
        },
        {
          text: 'Article (with MDX)',
          href: getPermalink('markdown-elements-demo-post', 'post'),
        },
        {
          text: 'Category Page',
          href: getPermalink('tutorials', 'category'),
        },
        {
          text: 'Tag Page',
          href: getPermalink('astro', 'tag'),
        },
      ],
    },
     {
      text: 'About',
      href: getPermalink('/about'),
    },{
      text: 'Components',
      href: getPermalink('/homes/components-list'),
    }
    // {
    //   text: 'Careers',
    //   href: getPermalink('/'),
    // },
   
  ],
  actions: [{ text: 'Request Demo', href: 'https://github.com/arthelokyo/astrowind', target: '_blank' }],
};



export const footerData = {
  links: [
    {
      title: 'Product',
      links: [
        { text: 'Features', href: '#' },
        { text: 'Security', href: '#' },
        { text: 'Team', href: '#' },
        { text: 'Enterprise', href: '#' },
        { text: 'Customer stories', href: '#' },
        { text: 'Pricing', href: '#' },
        { text: 'Resources', href: '#' },
      ],
    },
    {
      title: 'Platform',
      links: [
        { text: 'Developer API', href: '#' },
        { text: 'Partners', href: '#' },
        { text: 'Atom', href: '#' },
        { text: 'Electron', href: '#' },
        { text: 'AstroWind Desktop', href: '#' },
      ],
    },
    {
      title: 'Support',
      links: [
        { text: 'Docs', href: '#' },
        { text: 'Community Forum', href: '#' },
        { text: 'Professional Services', href: '#' },
        { text: 'Skills', href: '#' },
        { text: 'Status', href: '#' },
      ],
    },
    {
      title: 'Company',
      links: [
        { text: 'About', href: '#' },
        { text: 'Blog', href: '#' },
        { text: 'Careers', href: '#' },
        { text: 'Press', href: '#' },
        { text: 'Inclusion', href: '#' },
        { text: 'Social Impact', href: '#' },
        { text: 'Shop', href: '#' },
      ],
    },
  ],
  secondaryLinks: [
    { text: 'Terms', href: getPermalink('/terms') },
    { text: 'Privacy Policy', href: getPermalink('/privacy') },
  ],
  socialLinks: [
    { ariaLabel: 'X', icon: 'tabler:brand-x', href: '#' },
    { ariaLabel: 'Instagram', icon: 'tabler:brand-instagram', href: '#' },
    { ariaLabel: 'Facebook', icon: 'tabler:brand-facebook', href: '#' },
    { ariaLabel: 'RSS', icon: 'tabler:rss', href: getAsset('/rss.xml') },
    { ariaLabel: 'Github', icon: 'tabler:brand-github', href: 'https://github.com/arthelokyo/astrowind' },
  ],
  footNote: `
    Made by <a class="text-blue-600 underline dark:text-muted" href="https://github.com/arthelokyo"> Arthelokyo</a> · All rights reserved.
  `,
};
